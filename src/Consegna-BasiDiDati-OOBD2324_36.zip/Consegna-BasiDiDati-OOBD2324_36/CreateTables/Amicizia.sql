CREATE TABLE Amicizia (
    MatricolaUtente1 CHAR(9),
    MatricolaUtente2 CHAR(9),
    Data_Richiesta DATE NOT NULL,
    Stato_Amicizia VARCHAR(15) NOT NULL,
    CONSTRAINT fk_Amicizia1 FOREIGN KEY (MatricolaUtente1)
        REFERENCES Utente (Matricola)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_Amicizia2 FOREIGN KEY (MatricolaUtente2)
        REFERENCES Utente (Matricola)
        ON DELETE CASCADE ON UPDATE CASCADE
);
ALTER TABLE Amicizia
ADD CONSTRAINT EnumA
CHECK (Stato_Amicizia IN ('Accettata','Rifiutata','In_Attesa'));

ALTER TABLE Amicizia
ADD CONSTRAINT Unique_Amicizia UNIQUE
(MatricolaUtente1,MatricolaUtente2);
