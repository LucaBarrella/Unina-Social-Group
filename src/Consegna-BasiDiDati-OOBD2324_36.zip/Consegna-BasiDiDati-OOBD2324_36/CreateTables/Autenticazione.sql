CREATE TABLE Autenticazione (
    ID_Autenticazione CHAR(10) PRIMARY KEY,
    Email VARCHAR(100) NOT NULL,
    Password VARCHAR(100) NOT NULL
);
