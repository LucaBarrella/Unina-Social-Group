CREATE TABLE Commento (
    ID_Commento CHAR(10) PRIMARY KEY,
    Testo_Scritto VARCHAR(10000) NOT NULL,
    Data_di_Pubblicazione DATE NOT NULL,
    Ora_di_Pubblicazione TIME NOT NULL,
    ID_Post CHAR(10),
    Matricola CHAR(9),
    CONSTRAINT fk_Commento1 FOREIGN KEY (Matricola)
        REFERENCES Utente (Matricola)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_Commento2 FOREIGN KEY (ID_Post)
        REFERENCES Post (ID_Post)
        ON DELETE CASCADE ON UPDATE CASCADE
);
