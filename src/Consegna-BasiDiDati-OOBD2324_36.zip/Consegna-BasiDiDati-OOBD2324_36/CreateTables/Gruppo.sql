CREATE TABLE Gruppo (
    ID_Gruppo CHAR(10) PRIMARY KEY,
    Nome_Gruppo VARCHAR(100) NOT NULL,
    Data_di_Creazione DATE NOT NULL,
    Categoria_Gruppo VARCHAR(100) NOT NULL,
    GestoreGruppo CHAR(9),
    CONSTRAINT fk_Gruppo FOREIGN KEY (GestoreGruppo)
        REFERENCES Utente (Matricola)
        ON DELETE CASCADE ON UPDATE CASCADE
);
