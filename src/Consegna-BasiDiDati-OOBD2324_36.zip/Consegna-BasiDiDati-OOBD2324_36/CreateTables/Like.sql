CREATE TABLE Likes (
    Matricola CHAR(9),
    ID_Post CHAR(10),
    Data_Like DATE NOT NULL,
    Ora_Like TIME NOT NULL,
    CONSTRAINT fk_Like1 FOREIGN KEY (Matricola)
        REFERENCES Utente (Matricola)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_Like2 FOREIGN KEY (ID_Post)
        REFERENCES Post (ID_Post)
        ON DELETE CASCADE ON UPDATE CASCADE
);

ALTER TABLE Likes
ADD CONSTRAINT Unique_Like UNIQUE
(matricola,ID_Post);