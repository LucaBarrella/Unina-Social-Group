CREATE TABLE Notifica (
    ID_Notifica CHAR(10) PRIMARY KEY,
    Messaggio VARCHAR(100) NOT NULL,
    Data_Invio DATE NOT NULL,
    Ora_Invio TIME NOT NULL,
    ID_Post CHAR(10),
    CONSTRAINT fk_Notifica FOREIGN KEY (ID_Post)
        REFERENCES Post (ID_Post)
        ON DELETE CASCADE ON UPDATE CASCADE
);
