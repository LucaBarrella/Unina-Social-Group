CREATE TABLE Partecipa (
    Matricola CHAR(9),
    ID_Gruppo CHAR(10),
    CONSTRAINT fk_Partecipa1 FOREIGN KEY (Matricola)
        REFERENCES Utente (Matricola)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_Partecipa2 FOREIGN KEY (ID_Gruppo)
        REFERENCES Gruppo (ID_Gruppo)
        ON DELETE CASCADE ON UPDATE CASCADE
);

ALTER TABLE partecipa
ADD CONSTRAINT Unique_Partecipa UNIQUE
(matricola,id_gruppo);