CREATE TABLE Post (
    ID_Post CHAR(10) PRIMARY KEY,
    Categoria VARCHAR(100) NOT NULL,
    Data_Pubblicazione DATE NOT NULL,
    Messaggio_Scritto VARCHAR(1000),
    Percorso_File VARCHAR(250),
    Estensione VARCHAR(6),
    Tipo_Post VARCHAR(20) NOT NULL,
    Matricola CHAR(9),
    ID_Gruppo CHAR(10),
    CONSTRAINT fk_Post FOREIGN KEY (Matricola)
        REFERENCES Utente (Matricola)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_Post2 FOREIGN KEY (ID_Gruppo)
        REFERENCES Gruppo (ID_Gruppo)
        ON DELETE CASCADE ON UPDATE CASCADE
);

ALTER TABLE Post
ADD CONSTRAINT EnumP
CHECK(Tipo_Post IN ('Post_Foto','Post_Testuale','Post_Foto_Testuale'));


ALTER TABLE Post
ADD CONSTRAINT Check_Post CHECK((Tipo_Post = 'Post_Foto'
				AND Messaggio_Scritto IS NULL
				AND Percorso_File IS NOT NULL
				AND Estensione IS NOT NULL) OR 
				(Tipo_Post = 'Post_Testuale'
				AND Messaggio_Scritto IS NOT NULL
				AND Percorso_File IS NULL
				AND Estensione IS NULL) OR 
				(Tipo_Post = 'Post_Foto_Testuale'
				AND Messaggio_Scritto IS NOT NULL
				AND Percorso_File IS NOT NULL
				AND Estensione IS NOT NULL));

ALTER TABLE Post
ADD CONSTRAINT EnumEst 
CHECK (Estensione IN ('png','jpeg','jpg','heif'));

