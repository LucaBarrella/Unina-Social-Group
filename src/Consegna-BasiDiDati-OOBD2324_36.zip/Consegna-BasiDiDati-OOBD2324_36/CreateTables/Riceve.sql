CREATE TABLE Riceve (
    Matricola CHAR(9),
    ID_Notifica CHAR(10),
    CONSTRAINT fk_Riceve1 FOREIGN KEY (Matricola)
        REFERENCES Utente (Matricola)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_Riceve2 FOREIGN KEY (ID_Notifica)
        REFERENCES Notifica (ID_Notifica)
        ON DELETE CASCADE ON UPDATE CASCADE
);

ALTER TABLE Riceve
ADD CONSTRAINT Unique_Riceve UNIQUE
(matricola,id_notifica);
