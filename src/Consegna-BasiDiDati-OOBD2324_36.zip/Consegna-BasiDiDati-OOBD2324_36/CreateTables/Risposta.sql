CREATE TABLE Risposta (
    Matricola CHAR(9),
    ID_Commento CHAR(10),
    Messaggio VARCHAR(10000) NOT NULL,
    CONSTRAINT fk_Risposta1 FOREIGN KEY (Matricola)
        REFERENCES Utente (Matricola)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_Risposta2 FOREIGN KEY (ID_Commento)
        REFERENCES Commento (ID_Commento)
        ON DELETE CASCADE ON UPDATE CASCADE
);
