CREATE TABLE Utente (
    Matricola CHAR(9) PRIMARY KEY,
    Nome VARCHAR(50) NOT NULL,
    Cognome VARCHAR(50) NOT NULL,
    Data_di_Nascita DATE NOT NULL,
    Data_di_Registrazione DATE NOT NULL,
    ID_Autenticazione CHAR(10),
    CONSTRAINT fk_Utente1 FOREIGN KEY (ID_Autenticazione)
        REFERENCES Autenticazione (ID_Autenticazione)
        ON DELETE CASCADE ON UPDATE CASCADE
);
