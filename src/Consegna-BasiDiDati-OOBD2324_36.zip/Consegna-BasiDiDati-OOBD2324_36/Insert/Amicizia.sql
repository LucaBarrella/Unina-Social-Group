INSERT INTO amicizia (matricolautente1, matricolautente2, data_richiesta, 
stato_amicizia)
VALUES
 ('N86000001', 'N86000002', '2024-01-01', 'Rifiutata'),
 ('N86000001', 'N86000003', '2024-01-08', 'Accettata'),
 ('N86000002', 'N86000001', '2024-01-15', 'In_attesa'),
 ('N86000002', 'N86000004', '2024-01-22', 'Rifiutata'),
 ('N86000003', 'N86000001', '2024-01-29', 'In_attesa'),
 ('N86000003', 'N86000002', '2024-02-05', 'Accettata'),
 ('N86000004', 'N86000001', '2024-02-12', 'Rifiutata'),
 ('N86000004', 'N86000003', '2024-02-19', 'In_attesa');