INSERT INTO commento (testo_scritto, data_di_pubblicazione, 
ora_di_pubblicazione, id_post, matricola) VALUES
 ('Anche a me piace molto René Ferretti, il suo personaggio è molto 
realistico!', '2024-02-17', '11:02:13', 1, 'N86000002'),
 ('La torta di mele sembra deliziosa, potresti condividere la ricetta?', 
'2024-02-17', '11:02:13', 2, 'N86000001'),
 ('Sono d''accordo, il nuovo album di Adele è fantastico!', '2024-02-17', 
'11:02:13', 3, 'N86000003'),
 ('Bellissima foto del concerto!', '2024-02-17', '11:02:13', 4, 'N86000002'),
 ('Sì, vorrei la ricetta della cheesecake ai lamponi!', '2024-02-17', '11:02:13', 5, 
'N86000001'),
 ('Quando ho poco tempo, mi piace cucinare pasta aglio e olio. È semplice e 
veloce!', '2024-02-17', '11:02:13', 6, 'N86000003'),
 ('Ho letto "Il nome della rosa" qualche anno fa e l''ho trovato molto 
interessante.', '2024-02-17', '11:02:13', 7, 'N86000002'),
 ('Il libro sembra interessante, potresti dirmi di più sul genere fantasy?', 
'2024-02-17', '11:02:13', 8, 'N86000001'),
 ('Ottimo post!', '2024-02-17', '12:36:40', 7, 'N86000005'),
 ('Interessante, non lo sapevo.', '2024-02-17', '12:37:31', 3, 'N86000004'),
 ('Interessante, non lo sapevo.', '2024-02-17', '12:37:31', 3, 'N86000017'),
 ('Grazie per aver condiviso!', '2024-02-17', '12:38:28', 8, 'N86000015'),
 ('Grazie per aver condiviso!', '2024-02-17', '12:38:28', 3, 'N86000005'),
 ('Non mi piace', '2024-02-17', '12:38:49', 6, 'N86000002'),
 ('Doveva vincere Goelier, ho comprato 63 sim per nulla! Dannati poteri forti', 
'2024-02-17', '12:39:35', 5, 'N86000003'),
 ('Forza Napoli!', '2024-02-17', '12:40:05', 5, 'N86000002'),
 ('Oggi è una bella giornata', '2024-02-17', '12:41:00', 6, 'N86000017'),
 ('Occhi del cuore 3, dove 6?????', '2024-02-17', '12:41:29', 2, 'N86000015'),
 ('Domanda, ma che ore sono?', '2024-02-17', '12:43:06', 4, 'N86000005'),
 ('Dopo questa castroneria, vado a giocare Fortnite, almeno lì non si parla di 
queste cose pesanti', '2024-02-17', '12:44:18', 5, 'N86000003');