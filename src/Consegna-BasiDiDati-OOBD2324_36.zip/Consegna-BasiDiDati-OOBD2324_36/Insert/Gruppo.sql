INSERT INTO gruppo (nome_gruppo, data_di_creazione, categoria_gruppo, 
gestoregruppo)
VALUES 
 ('Fan di Boris', '2024-02-16', 'Cinema e Film', 'N86000001'),
 ('Amanti della Musica', '2024-01-05', 'Musica', 'N86000002'),
 ('Gruppo di Lettura', '2024-01-12', 'Libri', 'N86000003'),
 ('Sportivi', '2024-01-19', 'Sport', 'N86000004'),
 ('Cucina Italiana', '2024-01-26', 'Cucina', 'N86000005'),
 ('Viaggiatori', '2024-02-02', 'Viaggi', 'N86000001'),
 ('Fotografia', '2024-02-09', 'Arte', 'N86000002'),
 ('Programmatori', '2024-02-16', 'Tecnologia', 'N86000003'),
 ('Gaming', '2024-02-22', 'Videogiochi', 'N86000004'),
 ('Amanti della Natura', '2024-02-15', 'Natura', 'N86000005');