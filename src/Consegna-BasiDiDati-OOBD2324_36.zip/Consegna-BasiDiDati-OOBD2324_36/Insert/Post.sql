INSERT INTO post (id_post, categoria, messaggio_scritto, percorso_file, 
estensione, tipo_post, matricola, data_pubblicazione, id_gruppo)
VALUES
 (NULL, 'Cinema e Film', 'Cari fan di Boris, oggi voglio condividere con voi la 
mia passione per questa serie che ci ha fatto ridere, commuovere e riflettere. 
Boris è una satira brillante e spietata del mondo della televisione, ma anche una 
storia di amicizia, amore e sogni. Mi piacciono tutti i personaggi, ma il mio 
preferito è sicuramente René Ferretti, il regista esasperato e geniale, 
interpretato dal grande Francesco Pannofino. Qual è il vostro personaggio 
preferito e perché? Fatemi sapere nei commenti!' , 'https://shorturl.at/hrGJK', 
'png', 'Post_Foto_Testuale', 'N86000001', '2024-02-06 10:24:31', 1),
 (NULL, 'Cucina', 'Oggi ho preparato una torta di mele. È venuta proprio 
bene!', 'https://shorturl.at/ghrUZ', 'png', 'Post_Foto_Testuale', 'N86000001', 
'2024-02-06 10:00:00', 5),
 (NULL, 'Musica', 'Oggi ho ascoltato il nuovo album di Adele. È incredibile 
come riesca sempre a toccare le corde giuste con la sua musica.', NULL, NULL, 
'Post_Testuale', 'N86000002', '2024-02-06 11:00:00', 2),
 (NULL, 'Musica', Null, 'https://shorturl.at/ghrUZ', 'jpg', 'Post_Foto', 
'N86000003', '2024-02-06 12:00:00', 2),
 (NULL, 'Cucina', 'Ho appena preparato questa deliziosa cheesecake ai 
lamponi! Qualcuno vuole la ricetta?', 'https://shorturl.at/ghrUZ', 'jpg', 
'Post_Foto_Testuale', 'N86000004', '2024-02-06 13:00:00', 5),
 (NULL, 'Cucina', 'Qual è il vostro piatto preferito da cucinare quando avete 
poco tempo?', NULL, NULL, 'Post_Testuale', 'N86000005', '2024-02-06 
14:00:00', 5),
 (NULL, 'Libri', 'Sto leggendo "Il nome della rosa" di Umberto Eco. È un 
romanzo affascinante, pieno di mistero e conoscenza.', NULL, NULL, 
'Post_Testuale', 'N86000006', '2024-02-06 15:00:00', 3),
 (NULL, 'Libri', 'Ecco la copertina del libro che sto leggendo in questo 
momento. Lo consiglio a tutti gli amanti del genere fantasy.', 'https://shorturl.at/
ghrUZ', 'jpg', 'Post_Foto_Testuale', 'N86000007', '2024-02-06 16:00:00', 3);