INSERT INTO risposta (matricola, id_commento, messaggio)
VALUES
 ('N86000016', 1, 'Fotografia?! Cosa vuoi tu, Duccio. Oh Duccio, voglio la roba 
la roba tua, quella de una volta, voglio che apri tutto. (Inspirazione nasale) 
Voglio che smarmelli!'),
 ('N86000012', 1, 'Duccio abbraccia Renè egli dice che lo vuole bene, scena 
divertentissima! Dai, dai, dai!'),
 ('N86000002', 1, 'Il top quando duccio si rifiresce a Lorenzo, lo stagista di 
fotografia e gli dice: "Hai capito che cosa ha detto Renè, che la tua fotografia fa 
schifo, io ti volevo dare una possibiltà, ma tu non l''hai saputa cogliere, perchè 
hai voluto fare una fotografia politica, ignaro del fatto che i muri sono caduti, 
adesso è tornato il tempo di "Aprire tutto!" Biascica, apri tutto!"'),
 ('N86000001', 9, 'Gomblotto!1!1'),
 ('N86000015', 8, 'Mi piace, sai come ragioni'),
 ('N86000004', 15, 'nn capt?'),
 ('N86000003', 17 , 'Vendo Levi''s da uomo, usate pochissimo, astenersi 
affaristi, sognatori e perditempo. Prezzo non trattabile.'),
 ('N86000002',5 , 'interessante congettura');