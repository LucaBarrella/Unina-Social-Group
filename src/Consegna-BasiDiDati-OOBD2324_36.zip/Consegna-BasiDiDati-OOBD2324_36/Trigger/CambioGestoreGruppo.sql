CREATE OR REPLACE FUNCTION CambioGestoreGruppo()
RETURNS TRIGGER AS $$
DECLARE
    gestore CHAR(9);
    gruppo RECORD;
    gruppo_cur CURSOR FOR
        SELECT ID_Gruppo
        FROM Gruppo
        WHERE GestoreGruppo = OLD.Matricola;
BEGIN
    OPEN gruppo_cur;
    LOOP
        FETCH gruppo_cur INTO gruppo;
        EXIT WHEN NOT FOUND;

        SELECT Matricola
        INTO gestore
        FROM Partecipa
        WHERE ID_Gruppo = gruppo.ID_Gruppo AND Matricola != OLD.Matricola
        LIMIT 1;

        IF gestore IS NOT NULL THEN
            UPDATE Gruppo
            SET GestoreGruppo = gestore
            WHERE ID_Gruppo = gruppo.ID_Gruppo;
        END IF;
    END LOOP;
    CLOSE gruppo_cur;

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER CambioGestoreGruppo
BEFORE DELETE ON Utente
FOR EACH ROW
EXECUTE FUNCTION CambioGestoreGruppo();