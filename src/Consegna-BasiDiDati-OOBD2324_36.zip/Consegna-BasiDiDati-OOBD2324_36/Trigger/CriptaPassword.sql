CREATE OR REPLACE FUNCTION CriptaPassword()
RETURNS TRIGGER AS $$
BEGIN
  NEW.password := REPLACE(
    TRANSLATE(
      NEW.password,
      'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$&-+!?;:*',
      'defghijklmnopqrstuvwxyzabcDEFGHIJKLMNOPQRSTUVWXYZABC3456789012&-+!?;:*@#$'
    ),
    ' ', ''
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER CriptaPassword
BEFORE INSERT ON Autenticazione
FOR EACH ROW
EXECUTE FUNCTION CriptaPassword();