CREATE OR REPLACE FUNCTION Maggiorenne()
RETURNS TRIGGER AS $$
BEGIN
    IF DATE_PART('year', age(NEW.Data_di_Nascita)) < 18 THEN
        DELETE FROM autenticazione WHERE ID_Autenticazione = NEW.ID_Autenticazione;
    end if;
    RETURN NEW;
END
$$ LANGUAGE plpgsql;

CREATE TRIGGER Maggiorenne
AFTER INSERT ON utente
FOR EACH ROW 
EXECUTE FUNCTION Maggiorenne();
