CREATE OR REPLACE FUNCTION NotificaNuovoPost()
RETURNS TRIGGER AS $$
DECLARE
    GruppoDiPubblicazione CHAR(10);
    IDNotifica CHAR(10);
BEGIN
    IDNotifica = CAST((SELECT COALESCE(MAX(CAST(ID_Notifica AS INTEGER)),0)+1 FROM Notifica) AS CHAR(10));

    SELECT ID_Gruppo
    INTO GruppoDiPubblicazione
    FROM Post
    WHERE ID_Post = NEW.ID_Post;

    INSERT INTO Notifica (ID_Notifica, Messaggio, Data_Invio, Ora_Invio, ID_Post)
    VALUES (IDNotifica,'Un nuovo post è stato inserito!', CURRENT_DATE,CURRENT_TIME, NEW.ID_Post);

    INSERT INTO Riceve (Matricola, ID_Notifica)
    SELECT Matricola,IDNotifica
    FROM Partecipa
    WHERE ID_Gruppo = GruppoDiPubblicazione AND Matricola <> NEW.Matricola;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER NotificaNuovoPost
AFTER INSERT ON Post
FOR EACH ROW
EXECUTE FUNCTION NotificaNuovoPost();
