CREATE OR REPLACE FUNCTION Post_Eliminato()
RETURNS TRIGGER AS $$
BEGIN
    DELETE FROM Risposta WHERE ID_Commento IN (SELECT ID_Commento 
                                               FROM Commento 
                                               WHERE ID_Post = OLD.ID_Post);
    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER PostEliminato
AFTER DELETE ON Post
FOR EACH ROW
EXECUTE FUNCTION Post_Eliminato();
