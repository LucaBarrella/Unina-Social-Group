CREATE OR REPLACE FUNCTION SetIDAutenticazione()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.ID_Autenticazione IS NULL THEN
        NEW.ID_Autenticazione := CAST((SELECT COALESCE(MAX(CAST(ID_Autenticazione AS INTEGER)),0)+1 FROM Autenticazione) AS CHAR(10));
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER SetIDAutenticazione
BEFORE INSERT ON Autenticazione
FOR EACH ROW
EXECUTE FUNCTION SetIDAutenticazione();
