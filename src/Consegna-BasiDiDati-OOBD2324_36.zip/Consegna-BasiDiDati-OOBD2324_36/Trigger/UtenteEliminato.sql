CREATE OR REPLACE FUNCTION Utente_Eliminato()
RETURNS TRIGGER AS $$
BEGIN
    DELETE FROM Autenticazione WHERE ID_Autenticazione = OLD.ID_Autenticazione;
    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER UtenteEliminato
AFTER DELETE ON Utente
FOR EACH ROW
EXECUTE FUNCTION Utente_Eliminato();
