--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: UninaSocialGroup; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "UninaSocialGroup";


ALTER SCHEMA "UninaSocialGroup" OWNER TO postgres;

--
-- Name: cambiogestoregruppo(); Type: FUNCTION; Schema: UninaSocialGroup; Owner: postgres
--

CREATE FUNCTION "UninaSocialGroup".cambiogestoregruppo() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    gestore CHAR(9);
    gruppo_cur CURSOR FOR
        SELECT ID_Gruppo
        FROM Gruppo
        WHERE GestoreGruppo = OLD.Matricola;
    gruppo RECORD;
BEGIN
    OPEN gruppo_cur;
    LOOP
        FETCH gruppo_cur INTO gruppo;
        EXIT WHEN NOT FOUND;

        SELECT Matricola
        INTO gestore
        FROM Partecipa
        WHERE ID_Gruppo = gruppo.ID_Gruppo AND Matricola != OLD.Matricola
        LIMIT 1;

        IF gestore IS NOT NULL THEN
            UPDATE Gruppo
            SET GestoreGruppo = gestore
            WHERE ID_Gruppo = gruppo.ID_Gruppo;
        END IF;
    END LOOP;
    CLOSE gruppo_cur;

    RETURN OLD;
END;
$$;


ALTER FUNCTION "UninaSocialGroup".cambiogestoregruppo() OWNER TO postgres;

--
-- Name: criptapassword(); Type: FUNCTION; Schema: UninaSocialGroup; Owner: postgres
--

CREATE FUNCTION "UninaSocialGroup".criptapassword() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
BEGIN
  NEW.password := REPLACE(
    TRANSLATE(
      NEW.password,
      'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$&-+!?;:*',
      'defghijklmnopqrstuvwxyzabcDEFGHIJKLMNOPQRSTUVWXYZABC3456789012&-+!?;:*@#$'
    ),
    ' ', ''
  );
  RETURN NEW;
END;
$_$;


ALTER FUNCTION "UninaSocialGroup".criptapassword() OWNER TO postgres;

--
-- Name: maggiorenne(); Type: FUNCTION; Schema: UninaSocialGroup; Owner: postgres
--

CREATE FUNCTION "UninaSocialGroup".maggiorenne() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF DATE_PART('year',age(NEW.Data_di_Nascita)) < 18 THEN
        DELETE FROM autenticazione WHERE ID_Autenticazione = NEW.ID_Autenticazione;
    end if;
    RETURN NEW;
END
$$;


ALTER FUNCTION "UninaSocialGroup".maggiorenne() OWNER TO postgres;

--
-- Name: notificanuovopost(); Type: FUNCTION; Schema: UninaSocialGroup; Owner: postgres
--

CREATE FUNCTION "UninaSocialGroup".notificanuovopost() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    GruppoDiPubblicazione CHAR(10);
    IDNotifica CHAR(10);
BEGIN
    IDNotifica = CAST((SELECT COALESCE(MAX(CAST(ID_Notifica AS INTEGER)),0)+1 FROM Notifica) AS CHAR(10));

    SELECT ID_Gruppo
    INTO GruppoDiPubblicazione
    FROM Post
    WHERE ID_Post = NEW.ID_Post;

    INSERT INTO Notifica (ID_Notifica, Messaggio, Data_Invio, Ora_Invio, ID_Post)
    VALUES (IDNotifica,'Un nuovo post è stato inserito!', CURRENT_DATE,CURRENT_TIME, NEW.ID_Post);

    INSERT INTO Riceve (Matricola, ID_Notifica)
    SELECT Matricola,IDNotifica
    FROM Partecipa
    WHERE ID_Gruppo = GruppoDiPubblicazione AND Matricola <> NEW.Matricola;

    RETURN NEW;
END;
$$;


ALTER FUNCTION "UninaSocialGroup".notificanuovopost() OWNER TO postgres;

--
-- Name: post_eliminato(); Type: FUNCTION; Schema: UninaSocialGroup; Owner: postgres
--

CREATE FUNCTION "UninaSocialGroup".post_eliminato() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM Risposta WHERE ID_Commento IN (SELECT ID_Commento
                                               FROM Commento
                                               WHERE ID_Post = OLD.ID_Post);
    RETURN OLD;
END;
$$;


ALTER FUNCTION "UninaSocialGroup".post_eliminato() OWNER TO postgres;

--
-- Name: setidautenticazione(); Type: FUNCTION; Schema: UninaSocialGroup; Owner: postgres
--

CREATE FUNCTION "UninaSocialGroup".setidautenticazione() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.ID_Autenticazione IS NULL THEN
        NEW.ID_Autenticazione := CAST((SELECT COALESCE(MAX(CAST(ID_Autenticazione AS INTEGER)),0)+1 FROM Autenticazione) AS CHAR(10));
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION "UninaSocialGroup".setidautenticazione() OWNER TO postgres;

--
-- Name: setidcommento(); Type: FUNCTION; Schema: UninaSocialGroup; Owner: postgres
--

CREATE FUNCTION "UninaSocialGroup".setidcommento() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.ID_Commento IS NULL THEN
        NEW.ID_Commento := CAST((SELECT COALESCE(MAX(CAST(ID_Commento AS INTEGER)),0)+1 FROM Commento) AS CHAR(10));
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION "UninaSocialGroup".setidcommento() OWNER TO postgres;

--
-- Name: setidgruppo(); Type: FUNCTION; Schema: UninaSocialGroup; Owner: postgres
--

CREATE FUNCTION "UninaSocialGroup".setidgruppo() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.ID_Gruppo IS NULL THEN
        NEW.ID_Gruppo := CAST((SELECT COALESCE(MAX(CAST(ID_Gruppo AS INTEGER)),0)+1 FROM Gruppo) AS CHAR(10));
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION "UninaSocialGroup".setidgruppo() OWNER TO postgres;

--
-- Name: setidpost(); Type: FUNCTION; Schema: UninaSocialGroup; Owner: postgres
--

CREATE FUNCTION "UninaSocialGroup".setidpost() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.ID_Post IS NULL THEN
        NEW.ID_Post := CAST((SELECT COALESCE(MAX(CAST(ID_Post AS INTEGER)),0)+1 FROM Post) AS CHAR(10));
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION "UninaSocialGroup".setidpost() OWNER TO postgres;

--
-- Name: utente_eliminato(); Type: FUNCTION; Schema: UninaSocialGroup; Owner: postgres
--

CREATE FUNCTION "UninaSocialGroup".utente_eliminato() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM Autenticazione WHERE ID_Autenticazione = OLD.ID_Autenticazione;
    RETURN OLD;
END;
$$;


ALTER FUNCTION "UninaSocialGroup".utente_eliminato() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: amicizia; Type: TABLE; Schema: UninaSocialGroup; Owner: postgres
--

CREATE TABLE "UninaSocialGroup".amicizia (
    matricolautente1 character(9),
    matricolautente2 character(9),
    data_richiesta date NOT NULL,
    stato_amicizia character varying(15) NOT NULL,
    CONSTRAINT enumam CHECK (((stato_amicizia)::text = ANY ((ARRAY['Accettata'::character varying, 'Rifiutata'::character varying, 'In_attesa'::character varying])::text[])))
);


ALTER TABLE "UninaSocialGroup".amicizia OWNER TO postgres;

--
-- Name: autenticazione; Type: TABLE; Schema: UninaSocialGroup; Owner: postgres
--

CREATE TABLE "UninaSocialGroup".autenticazione (
    id_autenticazione character(10) NOT NULL,
    email character varying(100) NOT NULL,
    password character varying(100) NOT NULL
);


ALTER TABLE "UninaSocialGroup".autenticazione OWNER TO postgres;

--
-- Name: commento; Type: TABLE; Schema: UninaSocialGroup; Owner: postgres
--

CREATE TABLE "UninaSocialGroup".commento (
    id_commento character(10) NOT NULL,
    testo_scritto character varying(10000) NOT NULL,
    data_di_pubblicazione date NOT NULL,
    ora_di_pubblicazione time without time zone NOT NULL,
    id_post character(10),
    matricola character(9)
);


ALTER TABLE "UninaSocialGroup".commento OWNER TO postgres;

--
-- Name: gruppo; Type: TABLE; Schema: UninaSocialGroup; Owner: postgres
--

CREATE TABLE "UninaSocialGroup".gruppo (
    id_gruppo character(10) NOT NULL,
    nome_gruppo character varying(100) NOT NULL,
    data_di_creazione date NOT NULL,
    categoria_gruppo character varying(100) NOT NULL,
    gestoregruppo character(9)
);


ALTER TABLE "UninaSocialGroup".gruppo OWNER TO postgres;

--
-- Name: likes; Type: TABLE; Schema: UninaSocialGroup; Owner: postgres
--

CREATE TABLE "UninaSocialGroup".likes (
    matricola character(9),
    id_post character(10),
    data_like date NOT NULL,
    ora_like time without time zone NOT NULL
);


ALTER TABLE "UninaSocialGroup".likes OWNER TO postgres;

--
-- Name: notifica; Type: TABLE; Schema: UninaSocialGroup; Owner: postgres
--

CREATE TABLE "UninaSocialGroup".notifica (
    id_notifica character(10) NOT NULL,
    messaggio character varying(100) NOT NULL,
    data_invio date NOT NULL,
    ora_invio time without time zone NOT NULL,
    id_post character(10)
);


ALTER TABLE "UninaSocialGroup".notifica OWNER TO postgres;

--
-- Name: partecipa; Type: TABLE; Schema: UninaSocialGroup; Owner: postgres
--

CREATE TABLE "UninaSocialGroup".partecipa (
    matricola character(9),
    id_gruppo character(10)
);


ALTER TABLE "UninaSocialGroup".partecipa OWNER TO postgres;

--
-- Name: post; Type: TABLE; Schema: UninaSocialGroup; Owner: postgres
--

CREATE TABLE "UninaSocialGroup".post (
    id_post character(10) NOT NULL,
    categoria character varying(100) NOT NULL,
    messaggio_scritto character varying(1000),
    percorso_file character varying(250),
    estensione character varying(6),
    tipo_post character varying(20) NOT NULL,
    matricola character(9),
    data_pubblicazione date NOT NULL,
    id_gruppo character(10),
    CONSTRAINT check_post CHECK (((((tipo_post)::text = 'Post_Foto'::text) AND (messaggio_scritto IS NULL) AND (percorso_file IS NOT NULL) AND (estensione IS NOT NULL)) OR (((tipo_post)::text = 'Post_Testuale'::text) AND (messaggio_scritto IS NOT NULL) AND (percorso_file IS NULL) AND (estensione IS NULL)) OR (((tipo_post)::text = 'Post_Foto_Testuale'::text) AND (messaggio_scritto IS NOT NULL) AND (percorso_file IS NOT NULL) AND (estensione IS NOT NULL)))),
    CONSTRAINT enumest CHECK (((estensione)::text = ANY ((ARRAY['png'::character varying, 'jpeg'::character varying, 'jpg'::character varying, 'heif'::character varying])::text[]))),
    CONSTRAINT enump CHECK (((tipo_post)::text = ANY ((ARRAY['Post_Foto'::character varying, 'Post_Testuale'::character varying, 'Post_Foto_Testuale'::character varying])::text[])))
);


ALTER TABLE "UninaSocialGroup".post OWNER TO postgres;

--
-- Name: riceve; Type: TABLE; Schema: UninaSocialGroup; Owner: postgres
--

CREATE TABLE "UninaSocialGroup".riceve (
    matricola character(9),
    id_notifica character(10)
);


ALTER TABLE "UninaSocialGroup".riceve OWNER TO postgres;

--
-- Name: risposta; Type: TABLE; Schema: UninaSocialGroup; Owner: postgres
--

CREATE TABLE "UninaSocialGroup".risposta (
    matricola character(9),
    id_commento character(10),
    messaggio character varying(10000) NOT NULL
);


ALTER TABLE "UninaSocialGroup".risposta OWNER TO postgres;

--
-- Name: utente; Type: TABLE; Schema: UninaSocialGroup; Owner: postgres
--

CREATE TABLE "UninaSocialGroup".utente (
    matricola character(9) NOT NULL,
    nome character varying(50) NOT NULL,
    cognome character varying(50) NOT NULL,
    data_di_nascita date NOT NULL,
    data_di_registrazione date NOT NULL,
    id_autenticazione character(10)
);


ALTER TABLE "UninaSocialGroup".utente OWNER TO postgres;

--
-- Data for Name: amicizia; Type: TABLE DATA; Schema: UninaSocialGroup; Owner: postgres
--

COPY "UninaSocialGroup".amicizia (matricolautente1, matricolautente2, data_richiesta, stato_amicizia) FROM stdin;
N86000001	N86000002	2024-01-01	Rifiutata
N86000001	N86000003	2024-01-08	Accettata
N86000002	N86000001	2024-01-15	In_attesa
N86000002	N86000004	2024-01-22	Rifiutata
N86000003	N86000001	2024-01-29	In_attesa
N86000003	N86000002	2024-02-05	Accettata
N86000004	N86000001	2024-02-12	Rifiutata
N86000004	N86000003	2024-02-19	In_attesa
\.


--
-- Data for Name: autenticazione; Type: TABLE DATA; Schema: UninaSocialGroup; Owner: postgres
--

COPY "UninaSocialGroup".autenticazione (id_autenticazione, email, password) FROM stdin;
1         	giovanni.rossi@studenti.unina.it	MoubgttoX7?
2         	maria.bianchi@studenti.unina.it	SgxogH8?
3         	luca.verdi@studenti.unina.it	RaigB9?
4         	francesca.neri@studenti.unina.it	LxgtikyigT0?
5         	marco.gialli@studenti.unina.it	SgxiuM1?
6         	laura.viola@studenti.unina.it	RgaxgB2?
7         	antonio.marrone@studenti.unina.it	GtzutouS3?
8         	giulia.azzurri@studenti.unina.it	MoarogG4?
9         	alberto.arancione@studenti.unina.it	GrhkxzuG5?
10        	roberto.rosso@studenti.unina.it	UewuUv4?
11        	anna.bianco@studenti.unina.it	DqqEqf5?
12        	marco.verde@studenti.unina.it	PufYug6?
13        	lucia.nero@studenti.unina.it	OfQu7?
14        	francesco.giallo@studenti.unina.it	IuqJoo8?
15        	andrea.viola@studenti.unina.it	OuYo9?
16        	antonio.marrone@studenti.unina.it	DqwqPuq0?
17        	giulia.azzurro@studenti.unina.it	JoDcu1?
18        	alberto.arancio@studenti.unina.it	DoeDuq2?
19        	carlo.blu@studenti.unina.it	FuoEo4?
20        	sergio.rosa@studenti.unina.it	VujUv3?
\.


--
-- Data for Name: commento; Type: TABLE DATA; Schema: UninaSocialGroup; Owner: postgres
--

COPY "UninaSocialGroup".commento (id_commento, testo_scritto, data_di_pubblicazione, ora_di_pubblicazione, id_post, matricola) FROM stdin;
1         	Anche a me piace molto René Ferretti, il suo personaggio è molto\r\nrealistico!	2024-02-17	11:02:13	1         	N86000002
2         	La torta di mele sembra deliziosa, potresti condividere la ricetta?	2024-02-17	11:02:13	2         	N86000001
3         	Sono d'accordo, il nuovo album di Adele è fantastico!	2024-02-17	11:02:13	3         	N86000003
4         	Bellissima foto del concerto!	2024-02-17	11:02:13	4         	N86000002
5         	Sì, vorrei la ricetta della cheesecake ai lamponi!	2024-02-17	11:02:13	5         	N86000001
6         	Quando ho poco tempo, mi piace cucinare pasta aglio e olio. È semplice e\r\nveloce!	2024-02-17	11:02:13	6         	N86000003
7         	Ho letto "Il nome della rosa" qualche anno fa e l'ho trovato molto\r\ninteressante.	2024-02-17	11:02:13	7         	N86000002
8         	Il libro sembra interessante, potresti dirmi di più sul genere fantasy?	2024-02-17	11:02:13	8         	N86000001
9         	Ottimo post!	2024-02-17	12:36:40	7         	N86000005
10        	Interessante, non lo sapevo.	2024-02-17	12:37:31	3         	N86000004
11        	Interessante, non lo sapevo.	2024-02-17	12:37:31	3         	N86000017
12        	Grazie per aver condiviso!	2024-02-17	12:38:28	8         	N86000015
13        	Grazie per aver condiviso!	2024-02-17	12:38:28	3         	N86000005
14        	Non mi piace	2024-02-17	12:38:49	6         	N86000002
15        	Doveva vincere Goelier, ho comprato 63 sim per nulla! Dannati poteri forti	2024-02-17	12:39:35	5         	N86000003
16        	Forza Napoli!	2024-02-17	12:40:05	5         	N86000002
17        	Oggi è una bella giornata	2024-02-17	12:41:00	6         	N86000017
18        	Occhi del cuore 3, dove 6?????	2024-02-17	12:41:29	2         	N86000015
19        	Domanda, ma che ore sono?	2024-02-17	12:43:06	4         	N86000005
20        	Dopo questa castroneria, vado a giocare Fortnite, almeno lì non si parla di\r\nqueste cose pesanti	2024-02-17	12:44:18	5         	N86000003
\.


--
-- Data for Name: gruppo; Type: TABLE DATA; Schema: UninaSocialGroup; Owner: postgres
--

COPY "UninaSocialGroup".gruppo (id_gruppo, nome_gruppo, data_di_creazione, categoria_gruppo, gestoregruppo) FROM stdin;
1         	Fan di Boris	2024-02-16	Cinema e Film	N86000001
2         	Amanti della Musica	2024-01-05	Musica	N86000002
3         	Gruppo di Lettura	2024-01-12	Libri	N86000003
4         	Sportivi	2024-01-19	Sport	N86000004
5         	Cucina Italiana	2024-01-26	Cucina	N86000005
6         	Viaggiatori	2024-02-02	Viaggi	N86000001
7         	Fotografia	2024-02-09	Arte	N86000002
8         	Programmatori	2024-02-16	Tecnologia	N86000003
9         	Gaming	2024-02-22	Videogiochi	N86000004
10        	Amanti della Natura	2024-02-15	Natura	N86000005
\.


--
-- Data for Name: likes; Type: TABLE DATA; Schema: UninaSocialGroup; Owner: postgres
--

COPY "UninaSocialGroup".likes (matricola, id_post, data_like, ora_like) FROM stdin;
N86000015	1         	2024-02-17	12:30:53
N86000016	1         	2024-02-17	12:30:53
N86000001	6         	2024-02-17	12:30:53
N86000004	2         	2024-02-17	12:30:53
N86000006	7         	2024-02-17	12:30:53
N86000015	2         	2024-02-17	12:30:53
N86000004	5         	2024-02-17	12:30:53
N86000017	1         	2024-02-17	12:30:53
N86000003	5         	2024-02-17	12:30:53
N86000015	8         	2024-02-17	12:30:53
N86000001	2         	2024-02-17	12:30:53
N86000004	8         	2024-02-17	12:30:53
N86000015	5         	2024-02-17	12:30:53
N86000001	5         	2024-02-17	12:30:53
N86000002	5         	2024-02-17	12:30:53
N86000004	1         	2024-02-17	12:30:53
N86000002	8         	2024-02-17	12:30:53
N86000015	4         	2024-02-17	12:30:53
N86000017	4         	2024-02-17	12:30:53
N86000017	3         	2024-02-17	12:30:53
N86000007	7         	2024-02-17	12:30:53
N86000003	4         	2024-02-17	12:30:53
N86000001	8         	2024-02-17	12:30:53
N86000017	6         	2024-02-17	12:30:53
N86000005	7         	2024-02-17	12:30:53
\.


--
-- Data for Name: notifica; Type: TABLE DATA; Schema: UninaSocialGroup; Owner: postgres
--

COPY "UninaSocialGroup".notifica (id_notifica, messaggio, data_invio, ora_invio, id_post) FROM stdin;
1         	Un nuovo post è stato inserito!	2024-02-17	14:46:02.912757	1         
2         	Un nuovo post è stato inserito!	2024-02-17	14:46:02.912757	2         
3         	Un nuovo post è stato inserito!	2024-02-17	14:46:02.912757	3         
4         	Un nuovo post è stato inserito!	2024-02-17	14:46:02.912757	4         
5         	Un nuovo post è stato inserito!	2024-02-17	14:46:02.912757	5         
6         	Un nuovo post è stato inserito!	2024-02-17	14:46:02.912757	6         
7         	Un nuovo post è stato inserito!	2024-02-17	14:46:02.912757	7         
8         	Un nuovo post è stato inserito!	2024-02-17	14:46:02.912757	8         
\.


--
-- Data for Name: partecipa; Type: TABLE DATA; Schema: UninaSocialGroup; Owner: postgres
--

COPY "UninaSocialGroup".partecipa (matricola, id_gruppo) FROM stdin;
N86000017	1         
N86000004	1         
N86000009	1         
N86000012	1         
N86000016	1         
N86000005	1         
N86000003	1         
N86000002	1         
N86000015	1         
N86000001	10        
N86000017	10        
N86000015	10        
N86000002	10        
N86000003	10        
N86000004	10        
N86000001	2         
N86000015	2         
N86000003	2         
N86000005	2         
N86000004	2         
N86000017	2         
N86000002	3         
N86000001	3         
N86000015	3         
N86000017	3         
N86000006	3         
N86000004	3         
N86000007	3         
N86000005	3         
N86000005	4         
N86000017	4         
N86000003	4         
N86000015	4         
N86000001	4         
N86000002	4         
N86000015	5         
N86000017	5         
N86000001	5         
N86000002	5         
N86000003	5         
N86000004	5         
N86000004	6         
N86000005	6         
N86000003	6         
N86000015	6         
N86000002	6         
N86000017	6         
N86000005	7         
N86000004	7         
N86000001	7         
N86000017	7         
N86000015	7         
N86000003	7         
N86000001	8         
N86000015	8         
N86000004	8         
N86000017	8         
N86000005	8         
N86000002	8         
N86000001	9         
N86000003	9         
N86000002	9         
N86000015	9         
N86000017	9         
N86000005	9         
\.


--
-- Data for Name: post; Type: TABLE DATA; Schema: UninaSocialGroup; Owner: postgres
--

COPY "UninaSocialGroup".post (id_post, categoria, messaggio_scritto, percorso_file, estensione, tipo_post, matricola, data_pubblicazione, id_gruppo) FROM stdin;
1         	Cinema e Film	Cari fan di Boris, oggi voglio condividere con voi la\r\nmia passione per questa serie che ci ha fatto ridere, commuovere e riflettere.\r\nBoris è una satira brillante e spietata del mondo della televisione, ma anche una\r\nstoria di amicizia, amore e sogni. Mi piacciono tutti i personaggi, ma il mio\r\npreferito è sicuramente René Ferretti, il regista esasperato e geniale,\r\ninterpretato dal grande Francesco Pannofino. Qual è il vostro personaggio\r\npreferito e perché? Fatemi sapere nei commenti!	https://shorturl.at/hrGJK	png	Post_Foto_Testuale	N86000001	2024-02-06	1         
2         	Cucina	Oggi ho preparato una torta di mele. È venuta proprio\r\nbene!	https://shorturl.at/ghrUZ	png	Post_Foto_Testuale	N86000001	2024-02-06	5         
3         	Musica	Oggi ho ascoltato il nuovo album di Adele. È incredibile\r\ncome riesca sempre a toccare le corde giuste con la sua musica.	\N	\N	Post_Testuale	N86000002	2024-02-06	2         
4         	Musica	\N	https://shorturl.at/ghrUZ	jpg	Post_Foto	N86000003	2024-02-06	2         
5         	Cucina	Ho appena preparato questa deliziosa cheesecake ai\r\nlamponi! Qualcuno vuole la ricetta?	https://shorturl.at/ghrUZ	jpg	Post_Foto_Testuale	N86000004	2024-02-06	5         
6         	Cucina	Qual è il vostro piatto preferito da cucinare quando avete\r\npoco tempo?	\N	\N	Post_Testuale	N86000005	2024-02-06	5         
7         	Libri	Sto leggendo "Il nome della rosa" di Umberto Eco. È un\r\nromanzo affascinante, pieno di mistero e conoscenza.	\N	\N	Post_Testuale	N86000006	2024-02-06	3         
8         	Libri	Ecco la copertina del libro che sto leggendo in questo\r\nmomento. Lo consiglio a tutti gli amanti del genere fantasy.	https://shorturl.at/\r\nghrUZ	jpg	Post_Foto_Testuale	N86000007	2024-02-06	3         
\.


--
-- Data for Name: riceve; Type: TABLE DATA; Schema: UninaSocialGroup; Owner: postgres
--

COPY "UninaSocialGroup".riceve (matricola, id_notifica) FROM stdin;
N86000017	1         
N86000004	1         
N86000009	1         
N86000012	1         
N86000016	1         
N86000005	1         
N86000003	1         
N86000002	1         
N86000015	1         
N86000015	2         
N86000017	2         
N86000002	2         
N86000003	2         
N86000004	2         
N86000001	3         
N86000015	3         
N86000003	3         
N86000005	3         
N86000004	3         
N86000017	3         
N86000001	4         
N86000015	4         
N86000005	4         
N86000004	4         
N86000017	4         
N86000015	5         
N86000017	5         
N86000001	5         
N86000002	5         
N86000003	5         
N86000015	6         
N86000017	6         
N86000001	6         
N86000002	6         
N86000003	6         
N86000004	6         
N86000002	7         
N86000001	7         
N86000015	7         
N86000017	7         
N86000004	7         
N86000007	7         
N86000005	7         
N86000002	8         
N86000001	8         
N86000015	8         
N86000017	8         
N86000006	8         
N86000004	8         
N86000005	8         
\.


--
-- Data for Name: risposta; Type: TABLE DATA; Schema: UninaSocialGroup; Owner: postgres
--

COPY "UninaSocialGroup".risposta (matricola, id_commento, messaggio) FROM stdin;
N86000016	1         	Fotografia?! Cosa vuoi tu, Duccio. Oh Duccio, voglio la roba\r\nla roba tua, quella de una volta, voglio che apri tutto. (Inspirazione nasale)\r\nVoglio che smarmelli!
N86000012	1         	Duccio abbraccia Renè egli dice che lo vuole bene, scena\r\ndivertentissima! Dai, dai, dai!
N86000002	1         	Il top quando duccio si rifiresce a Lorenzo, lo stagista di\r\nfotografia e gli dice: "Hai capito che cosa ha detto Renè, che la tua fotografia fa\r\nschifo, io ti volevo dare una possibiltà, ma tu non l'hai saputa cogliere, perchè\r\nhai voluto fare una fotografia politica, ignaro del fatto che i muri sono caduti,\r\nadesso è tornato il tempo di "Aprire tutto!" Biascica, apri tutto!"
N86000001	9         	Gomblotto!1!1
N86000015	8         	Mi piace, sai come ragioni
N86000004	15        	nn capt?
N86000003	17        	Vendo Levi's da uomo, usate pochissimo, astenersi\r\naffaristi, sognatori e perditempo. Prezzo non trattabile.
N86000002	5         	interessante congettura
\.


--
-- Data for Name: utente; Type: TABLE DATA; Schema: UninaSocialGroup; Owner: postgres
--

COPY "UninaSocialGroup".utente (matricola, nome, cognome, data_di_nascita, data_di_registrazione, id_autenticazione) FROM stdin;
N86000001	Giovanni	Rossi	2001-06-15	2024-01-20	1         
N86000002	Maria	Bianchi	2002-03-10	2024-01-25	2         
N86000003	Luca	Verdi	2000-12-05	2024-02-01	3         
N86000004	Francesca	Neri	2003-07-20	2024-02-05	4         
N86000005	Marco	Gialli	2004-01-30	2024-02-10	5         
N86000006	Laura	Viola	1999-11-15	2024-01-15	6         
N86000007	Antonio	Marrone	2002-08-25	2024-01-30	7         
N86000008	Giulia	Azzurri	2003-04-10	2024-02-15	8         
N86000009	Alberto	Arancione	2000-05-20	2024-01-10	9         
N86000010	Roberto	Rosso	2001-02-15	2024-01-22	10        
N86000011	Anna	Bianco	2002-05-10	2024-01-27	11        
N86000012	Marco	Verde	2000-09-05	2024-02-03	12        
N86000013	Lucia	Nero	2003-10-20	2024-02-07	13        
N86000014	Francesco	Giallo	2004-04-30	2024-02-12	14        
N86000015	Andrea	Viola	1999-08-15	2024-01-17	15        
N86000016	Antonio	Marrone	2002-06-25	2024-02-02	16        
N86000017	Giulia	Azzurro	2003-03-10	2024-02-17	17        
N86000018	Alberto	Arancio	2000-07-20	2024-01-12	18        
N86000019	Carlo	Blu	2001-11-30	2024-01-24	19        
N86000020	Sergio	Rosa	2003-12-15	2024-02-14	20        
\.


--
-- Name: autenticazione autenticazione_pkey; Type: CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".autenticazione
    ADD CONSTRAINT autenticazione_pkey PRIMARY KEY (id_autenticazione);


--
-- Name: commento commento_pkey; Type: CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".commento
    ADD CONSTRAINT commento_pkey PRIMARY KEY (id_commento);


--
-- Name: gruppo gruppo_pkey; Type: CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".gruppo
    ADD CONSTRAINT gruppo_pkey PRIMARY KEY (id_gruppo);


--
-- Name: notifica notifica_pkey; Type: CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".notifica
    ADD CONSTRAINT notifica_pkey PRIMARY KEY (id_notifica);


--
-- Name: post post_pkey; Type: CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".post
    ADD CONSTRAINT post_pkey PRIMARY KEY (id_post);


--
-- Name: amicizia unique_amicizia; Type: CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".amicizia
    ADD CONSTRAINT unique_amicizia UNIQUE (matricolautente1, matricolautente2);


--
-- Name: likes unique_like; Type: CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".likes
    ADD CONSTRAINT unique_like UNIQUE (matricola, id_post);


--
-- Name: partecipa unique_partecipa; Type: CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".partecipa
    ADD CONSTRAINT unique_partecipa UNIQUE (matricola, id_gruppo);


--
-- Name: riceve unique_riceve; Type: CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".riceve
    ADD CONSTRAINT unique_riceve UNIQUE (matricola, id_notifica);


--
-- Name: utente utente_pkey; Type: CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".utente
    ADD CONSTRAINT utente_pkey PRIMARY KEY (matricola);


--
-- Name: utente cambiogestoregruppo; Type: TRIGGER; Schema: UninaSocialGroup; Owner: postgres
--

CREATE TRIGGER cambiogestoregruppo BEFORE DELETE ON "UninaSocialGroup".utente FOR EACH ROW EXECUTE FUNCTION "UninaSocialGroup".cambiogestoregruppo();


--
-- Name: autenticazione criptapassword; Type: TRIGGER; Schema: UninaSocialGroup; Owner: postgres
--

CREATE TRIGGER criptapassword BEFORE INSERT ON "UninaSocialGroup".autenticazione FOR EACH ROW EXECUTE FUNCTION "UninaSocialGroup".criptapassword();


--
-- Name: utente maggiorenne; Type: TRIGGER; Schema: UninaSocialGroup; Owner: postgres
--

CREATE TRIGGER maggiorenne AFTER INSERT ON "UninaSocialGroup".utente FOR EACH ROW EXECUTE FUNCTION "UninaSocialGroup".maggiorenne();


--
-- Name: post notificanuovopost; Type: TRIGGER; Schema: UninaSocialGroup; Owner: postgres
--

CREATE TRIGGER notificanuovopost AFTER INSERT ON "UninaSocialGroup".post FOR EACH ROW EXECUTE FUNCTION "UninaSocialGroup".notificanuovopost();


--
-- Name: post posteliminato; Type: TRIGGER; Schema: UninaSocialGroup; Owner: postgres
--

CREATE TRIGGER posteliminato AFTER DELETE ON "UninaSocialGroup".post FOR EACH ROW EXECUTE FUNCTION "UninaSocialGroup".post_eliminato();


--
-- Name: autenticazione setidautenticazione; Type: TRIGGER; Schema: UninaSocialGroup; Owner: postgres
--

CREATE TRIGGER setidautenticazione BEFORE INSERT ON "UninaSocialGroup".autenticazione FOR EACH ROW EXECUTE FUNCTION "UninaSocialGroup".setidautenticazione();


--
-- Name: commento setidcommento; Type: TRIGGER; Schema: UninaSocialGroup; Owner: postgres
--

CREATE TRIGGER setidcommento BEFORE INSERT ON "UninaSocialGroup".commento FOR EACH ROW EXECUTE FUNCTION "UninaSocialGroup".setidcommento();


--
-- Name: gruppo setidgruppo; Type: TRIGGER; Schema: UninaSocialGroup; Owner: postgres
--

CREATE TRIGGER setidgruppo BEFORE INSERT ON "UninaSocialGroup".gruppo FOR EACH ROW EXECUTE FUNCTION "UninaSocialGroup".setidgruppo();


--
-- Name: post setidpost; Type: TRIGGER; Schema: UninaSocialGroup; Owner: postgres
--

CREATE TRIGGER setidpost BEFORE INSERT ON "UninaSocialGroup".post FOR EACH ROW EXECUTE FUNCTION "UninaSocialGroup".setidpost();


--
-- Name: utente utenteeliminato; Type: TRIGGER; Schema: UninaSocialGroup; Owner: postgres
--

CREATE TRIGGER utenteeliminato AFTER DELETE ON "UninaSocialGroup".utente FOR EACH ROW EXECUTE FUNCTION "UninaSocialGroup".utente_eliminato();


--
-- Name: amicizia fk_amicizia1; Type: FK CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".amicizia
    ADD CONSTRAINT fk_amicizia1 FOREIGN KEY (matricolautente1) REFERENCES "UninaSocialGroup".utente(matricola) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: amicizia fk_amicizia2; Type: FK CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".amicizia
    ADD CONSTRAINT fk_amicizia2 FOREIGN KEY (matricolautente2) REFERENCES "UninaSocialGroup".utente(matricola) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commento fk_commento1; Type: FK CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".commento
    ADD CONSTRAINT fk_commento1 FOREIGN KEY (matricola) REFERENCES "UninaSocialGroup".utente(matricola) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: commento fk_commento2; Type: FK CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".commento
    ADD CONSTRAINT fk_commento2 FOREIGN KEY (id_post) REFERENCES "UninaSocialGroup".post(id_post) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: gruppo fk_gruppo; Type: FK CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".gruppo
    ADD CONSTRAINT fk_gruppo FOREIGN KEY (gestoregruppo) REFERENCES "UninaSocialGroup".utente(matricola) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: likes fk_like1; Type: FK CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".likes
    ADD CONSTRAINT fk_like1 FOREIGN KEY (matricola) REFERENCES "UninaSocialGroup".utente(matricola) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: likes fk_like2; Type: FK CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".likes
    ADD CONSTRAINT fk_like2 FOREIGN KEY (id_post) REFERENCES "UninaSocialGroup".post(id_post) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifica fk_notifica; Type: FK CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".notifica
    ADD CONSTRAINT fk_notifica FOREIGN KEY (id_post) REFERENCES "UninaSocialGroup".post(id_post) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: partecipa fk_partecipa1; Type: FK CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".partecipa
    ADD CONSTRAINT fk_partecipa1 FOREIGN KEY (matricola) REFERENCES "UninaSocialGroup".utente(matricola) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: partecipa fk_partecipa2; Type: FK CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".partecipa
    ADD CONSTRAINT fk_partecipa2 FOREIGN KEY (id_gruppo) REFERENCES "UninaSocialGroup".gruppo(id_gruppo) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: post fk_post; Type: FK CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".post
    ADD CONSTRAINT fk_post FOREIGN KEY (matricola) REFERENCES "UninaSocialGroup".utente(matricola) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: post fk_post2; Type: FK CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".post
    ADD CONSTRAINT fk_post2 FOREIGN KEY (id_gruppo) REFERENCES "UninaSocialGroup".gruppo(id_gruppo) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: riceve fk_riceve1; Type: FK CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".riceve
    ADD CONSTRAINT fk_riceve1 FOREIGN KEY (matricola) REFERENCES "UninaSocialGroup".utente(matricola) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: riceve fk_riceve2; Type: FK CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".riceve
    ADD CONSTRAINT fk_riceve2 FOREIGN KEY (id_notifica) REFERENCES "UninaSocialGroup".notifica(id_notifica) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: risposta fk_risposta1; Type: FK CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".risposta
    ADD CONSTRAINT fk_risposta1 FOREIGN KEY (matricola) REFERENCES "UninaSocialGroup".utente(matricola) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: risposta fk_risposta2; Type: FK CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".risposta
    ADD CONSTRAINT fk_risposta2 FOREIGN KEY (id_commento) REFERENCES "UninaSocialGroup".commento(id_commento) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: utente fk_utente1; Type: FK CONSTRAINT; Schema: UninaSocialGroup; Owner: postgres
--

ALTER TABLE ONLY "UninaSocialGroup".utente
    ADD CONSTRAINT fk_utente1 FOREIGN KEY (id_autenticazione) REFERENCES "UninaSocialGroup".autenticazione(id_autenticazione) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

